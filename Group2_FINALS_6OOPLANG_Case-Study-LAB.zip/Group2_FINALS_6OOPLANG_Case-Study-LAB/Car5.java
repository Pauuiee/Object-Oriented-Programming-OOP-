public class Car5 extends mainCar
{
    public Car5(){
        this.vehicleType = "Van";
        this.vehicleNumber = "PFN-5973";
        this.vehicleManufacturer = "Toyota";
        this.vehicleModel = "Hiace(2019)";
        this.vehicleTransmission = "Manual"; 
        this.vehicleColor = "Silver"; 
        this.vehicleRate = "3500";
        this.vehicleAdvance = "10500";
    }

    public String getVehicleType(){
        return vehicleType;
    }

    public String getVehicleNumber(){
        return vehicleNumber;
    }

    public String getVehicleManufacturer(){
        return vehicleManufacturer;
    }

    public String getVehicleModel(){
        return vehicleModel;
    }

    public String getVehicleTransmission(){
        return vehicleTransmission;
    }

    public String getVehicleColor(){
        return vehicleColor;
    }
    
    public String getVehicleRate(){
        return vehicleRate;
    }
    
    public String getVehicleAdvance(){
        return vehicleAdvance;
    }

}