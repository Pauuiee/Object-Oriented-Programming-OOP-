
public class Car2 extends mainCar
{
    public Car2(){
        this.vehicleType = "Sedan";
        this.vehicleNumber = "PGI-4523";
        this.vehicleManufacturer = "Hyundai";
        this.vehicleModel = "Accent(2016)";
        this.vehicleTransmission = "Automatic"; 
        this.vehicleColor = "Red"; 
        this.vehicleRate = "2000";
        this.vehicleAdvance = "6000";
        
        
    }
    
    public String getVehicleType(){
        return vehicleType;
    }
    
    public String getVehicleNumber(){
        return vehicleNumber;
    }
    
    public String getVehicleManufacturer(){
        return vehicleManufacturer;
    }
    
    public String getVehicleModel(){
        return vehicleModel;
    }
    
    public String getVehicleTransmission(){
        return vehicleTransmission;
    }
    
    public String getVehicleColor(){
        return vehicleColor;
    }
    
    public String getVehicleRate(){
        return vehicleRate;
    }
    
    public String getVehicleAdvance(){
        return vehicleAdvance;
    }
}
