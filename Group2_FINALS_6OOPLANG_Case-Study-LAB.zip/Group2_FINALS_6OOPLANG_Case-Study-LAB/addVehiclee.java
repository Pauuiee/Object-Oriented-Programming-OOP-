import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class addVehiclee {



     public static void main(String[] args){
         frame();
     }

     public static void frame(){
         DefaultTableModel model;

        JFrame f = new JFrame();

         f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
         f.setLocationRelativeTo(null);

         f.getContentPane().setLayout(new GridBagLayout());
         GridBagConstraints gridConstraints = new GridBagConstraints();

         //Title
         JLabel title = new JLabel("Add a Vehicle");
         title.setFont(new Font("Arial", Font.PLAIN, 25));
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 0;
         gridConstraints.insets = new Insets(10,0,30,0);
         f.getContentPane().add(title, gridConstraints);

         //Labels
         JLabel vehicleType = new JLabel("Vehicle Type");
         vehicleType.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 1;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(vehicleType, gridConstraints);

         JLabel vehicleNumber = new JLabel("Vehicle Number");
         vehicleNumber.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 2;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(vehicleNumber, gridConstraints);

         JLabel vehicleManufacturer = new JLabel("Vehicle Manufacturer");
         vehicleManufacturer.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 3;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(vehicleManufacturer, gridConstraints);

         JLabel vehicleModel = new JLabel("Vehicle Model");
         vehicleModel.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 4;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(vehicleModel, gridConstraints);

         JLabel vehicleTransmission = new JLabel("Vehicle Transmission");
         vehicleTransmission.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 5;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(vehicleTransmission, gridConstraints);

         JLabel vehicleColor = new JLabel("Vehicle Color");
         vehicleColor.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 6;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(vehicleColor, gridConstraints);

         //TextField
         JTextField text1 = new JTextField();
         text1.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 1;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text1, gridConstraints);

         JTextField text2 = new JTextField();
         text2.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 2;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text2, gridConstraints);

         JTextField text3 = new JTextField();
         text3.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 3;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text3, gridConstraints);

         JTextField text4 = new JTextField();
         text4.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 4;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text4, gridConstraints);

         JTextField text5 = new JTextField();
         text5.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 5;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text5, gridConstraints);

         JTextField text6 = new JTextField();
         text6.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 6;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text6, gridConstraints);

         //Buttons
         JButton addButton = new JButton("Add");
         addButton.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 15;
         gridConstraints.gridwidth = 2;
         gridConstraints.insets = new Insets(40,0,0,0);
         f.getContentPane().add(addButton, gridConstraints);


         JButton clearButton = new JButton("Clear");
         clearButton.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 15;
         gridConstraints.gridwidth = 2;
         gridConstraints.insets = new Insets(40,0,0,0);
         f.getContentPane().add(clearButton, gridConstraints);
         

         JButton exitButton = new JButton("Exit");
         exitButton.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 2;
         gridConstraints.gridy = 15;
         gridConstraints.gridwidth = 3;
         gridConstraints.insets = new Insets(40,0,0,0);
         f.getContentPane().add(exitButton, gridConstraints);




         f.setVisible(true);


         JTable table = new JTable ();

         table.setPreferredScrollableViewportSize(new Dimension(500, 200));
         table.setFillsViewportHeight(true);
         JScrollPane sp = new JScrollPane(table);
         model = new DefaultTableModel();
         Object[] column = {"Vehicle Type", "Vehicle Number", "Vehicle Manufacturer", "Vehicle Model", "Vehicle Transmission", "Vehicle Color"};
         final Object[] row = new Object[6];
         model.setColumnIdentifiers(column);
         table.setModel(model);
         table.getColumnModel().getColumn(3).setPreferredWidth(150);
         sp.setViewportView(table);
         gridConstraints.gridx = 3;
         gridConstraints.gridy = 1;
         gridConstraints.gridheight = 8;
         gridConstraints.insets = new Insets(0,20,0,0);
         f.getContentPane().add(sp, gridConstraints);
         
         
         Car1 carInfo1 = new Car1();
         //1st Table
         row[0] = carInfo1.getVehicleType();
         row[1] = carInfo1.getVehicleNumber();
         row[2] = carInfo1.getVehicleManufacturer();
         row[3] = carInfo1.getVehicleModel();
         row[4] = carInfo1.getVehicleTransmission();
         row[5] = carInfo1.getVehicleColor();
         model.addRow(row);
         
         Car2 carInfo2 = new Car2();
         //2nd Table
         row[0] = carInfo2.getVehicleType();
         row[1] = carInfo2.getVehicleNumber();
         row[2] = carInfo2.getVehicleManufacturer();
         row[3] = carInfo2.getVehicleModel();
         row[4] = carInfo2.getVehicleTransmission();
         row[5] = carInfo2.getVehicleColor();
         model.addRow(row);
         
         Car3 carInfo3 = new Car3();
         //3rd Table
         row[0] = carInfo3.getVehicleType();
         row[1] = carInfo3.getVehicleNumber();
         row[2] = carInfo3.getVehicleManufacturer();
         row[3] = carInfo3.getVehicleModel();
         row[4] = carInfo3.getVehicleTransmission();
         row[5] = carInfo3.getVehicleColor();
         model.addRow(row);
         
         Car4 carInfo4 = new Car4();
         //4th Table
         row[0] = carInfo4.getVehicleType();
         row[1] = carInfo4.getVehicleNumber();
         row[2] = carInfo4.getVehicleManufacturer();
         row[3] = carInfo4.getVehicleModel();
         row[4] = carInfo4.getVehicleTransmission();
         row[5] = carInfo4.getVehicleColor();
         model.addRow(row);
         
         Car5 carInfo5 = new Car5();
         //5th Table
         row[0] = carInfo5.getVehicleType();
         row[1] = carInfo5.getVehicleNumber();
         row[2] = carInfo5.getVehicleManufacturer();
         row[3] = carInfo5.getVehicleModel();
         row[4] = carInfo5.getVehicleTransmission();
         row[5] = carInfo5.getVehicleColor();
         model.addRow(row);
         
         Car6 carInfo6 = new Car6();
         //6th Table
         row[0] = carInfo6.getVehicleType();
         row[1] = carInfo6.getVehicleNumber();
         row[2] = carInfo6.getVehicleManufacturer();
         row[3] = carInfo6.getVehicleModel();
         row[4] = carInfo6.getVehicleTransmission();
         row[5] = carInfo6.getVehicleColor();
         model.addRow(row);
         
         Car7 carInfo7 = new Car7();
         //7th Table
         row[0] = carInfo7.getVehicleType();
         row[1] = carInfo7.getVehicleNumber();
         row[2] = carInfo7.getVehicleManufacturer();
         row[3] = carInfo7.getVehicleModel();
         row[4] = carInfo7.getVehicleTransmission();
         row[5] = carInfo7.getVehicleColor();
         model.addRow(row);

         addButton.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent arg0) {
                 
                 if (text1.getText().trim().length()==0){
                     JOptionPane.showMessageDialog(null, "You must complete all the information", "Invalid Input",
                     JOptionPane.ERROR_MESSAGE);
                 }
                 else if (text2.getText().trim().length()==0){
                     JOptionPane.showMessageDialog(null, "You must complete all the information", "Invalid Input",
                     JOptionPane.ERROR_MESSAGE);
                 }
                 else if (text3.getText().trim().length()==0){
                     JOptionPane.showMessageDialog(null, "You must complete all the information", "Invalid Input",
                     JOptionPane.ERROR_MESSAGE);
                 }
                 else if (text4.getText().trim().length()==0){
                     JOptionPane.showMessageDialog(null, "You must complete all the information", "Invalid Input",
                     JOptionPane.ERROR_MESSAGE);
                 }
                 else if (text5.getText().trim().length()==0){
                     JOptionPane.showMessageDialog(null, "You must complete all the information", "Invalid Input",
                     JOptionPane.ERROR_MESSAGE);
                 }
                 else if (text6.getText().trim().length()==0){
                     JOptionPane.showMessageDialog(null, "You must complete all the information", "Invalid Input",
                     JOptionPane.ERROR_MESSAGE);
                 }
                 else{
                     row[0] = text1.getText();
                     row[1] = text2.getText();
                     row[2] = text3.getText();
                     row[3] = text4.getText();
                     row[4] = text5.getText();
                     row[5] = text6.getText();
                     model.addRow(row);

                 }
                 
                
             }
         });
         
         clearButton.addActionListener(new ActionListener(){
             public void actionPerformed(ActionEvent arg0){
                text1.setText(null);
                text2.setText(null);
                text3.setText(null);
                text4.setText(null);
                text5.setText(null);
                text6.setText(null);

             }
         });
         
         exitButton.addActionListener(new ActionListener(){
             public void actionPerformed(ActionEvent arg0){
                 f.dispose();
            }    
         });
        
         

         f.pack();


     }
    
}
