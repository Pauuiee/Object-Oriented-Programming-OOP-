public class Car6 extends mainCar
{
    public Car6(){
        this.vehicleType = "Pickup Truck";
        this.vehicleNumber = "JGK-3212";
        this.vehicleManufacturer = "Mitsubishi";
        this.vehicleModel = "Strada(2016)";
        this.vehicleTransmission = "Manual"; 
        this.vehicleColor = "White"; 
        this.vehicleRate = "3000";
        this.vehicleAdvance = "9000";
    }

    public String getVehicleType(){
        return vehicleType;
    }

    public String getVehicleNumber(){
        return vehicleNumber;
    }

    public String getVehicleManufacturer(){
        return vehicleManufacturer;
    }

    public String getVehicleModel(){
        return vehicleModel;
    }

    public String getVehicleTransmission(){
        return vehicleTransmission;
    }

    public String getVehicleColor(){
        return vehicleColor;
    }
    
    public String getVehicleRate(){
        return vehicleRate;
    }
    
    public String getVehicleAdvance(){
        return vehicleAdvance;
    }

}