import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;

public class rentVehicle {



     public static void main(String[] args){
         frame();
     }

     public static void frame(){
         DefaultTableModel model;
         DefaultTableModel model2;

        JFrame f = new JFrame();

         f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
         f.setLocationRelativeTo(null);

         f.getContentPane().setLayout(new GridBagLayout());
         GridBagConstraints gridConstraints = new GridBagConstraints();

         //Title
         JLabel title = new JLabel("Rent a Vehicle");
         title.setFont(new Font("Arial", Font.PLAIN, 25));
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 0;
         gridConstraints.insets = new Insets(10,0,30,0);
         f.getContentPane().add(title, gridConstraints);

         //Labels
         JLabel nameLabel = new JLabel("Name");
         nameLabel.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 1;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(nameLabel, gridConstraints);

         JLabel vehicleNumber = new JLabel("Vehicle Number");
         vehicleNumber.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 2;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(vehicleNumber, gridConstraints);

         JLabel emailLabel = new JLabel("Email");
         emailLabel.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 3;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(emailLabel, gridConstraints);

         JLabel chargeLabel = new JLabel("Charge per day");
         chargeLabel.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 4;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(chargeLabel, gridConstraints);

         JLabel advanceLabel = new JLabel("Advanced");
         advanceLabel.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 5;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(advanceLabel, gridConstraints);
         
         JLabel date = new JLabel("Issue Date");
         date.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 6;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(date, gridConstraints);
         
         JLabel tableLabel1 = new JLabel("Available Vehicles");
         tableLabel1.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 4;
         gridConstraints.gridy = 0;
         gridConstraints.insets = new Insets(0,0,0,0);
         f.getContentPane().add(tableLabel1, gridConstraints);
         
         JLabel tableLabel2 = new JLabel("Rented Vehicles and Renters");
         tableLabel2.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 4;
         gridConstraints.gridy = 5;
         gridConstraints.insets = new Insets(0,0,0,0);
         f.getContentPane().add(tableLabel2, gridConstraints);
         


         //TextField
         JTextField text1 = new JTextField();
         text1.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 1;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text1, gridConstraints);

         JTextField text2 = new JTextField();
         text2.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 2;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text2, gridConstraints);

         JTextField text3 = new JTextField();
         text3.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 3;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text3, gridConstraints);

         JTextField text4 = new JTextField();
         text4.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 4;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text4, gridConstraints);

         JTextField text5 = new JTextField();
         text5.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 5;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text5, gridConstraints);
         
         JTextField text6 = new JTextField();
         text6.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 6;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text6, gridConstraints);

         //Buttons
         JButton addButton = new JButton("Rent");
         addButton.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 15;
         gridConstraints.gridwidth = 2;
         gridConstraints.insets = new Insets(40,0,0,0);
         f.getContentPane().add(addButton, gridConstraints);
         
         
         JButton fillButton = new JButton("Fill");
         fillButton.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 15;
         gridConstraints.gridwidth = 3;
         gridConstraints.insets = new Insets(40,0,0,0);
         f.getContentPane().add(fillButton, gridConstraints);


         JButton clearButton = new JButton("Clear");
         clearButton.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 2;
         gridConstraints.gridy = 15;
         gridConstraints.gridwidth = 2;
         gridConstraints.insets = new Insets(40,0,0,0);
         f.getContentPane().add(clearButton, gridConstraints);
         
         

         JButton exitButton = new JButton("Exit");
         exitButton.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 3;
         gridConstraints.gridy = 15;
         gridConstraints.gridwidth = 3;
         gridConstraints.insets = new Insets(40,0,0,0);
         f.getContentPane().add(exitButton, gridConstraints);
         
         




         f.setVisible(true);


         JTable table = new JTable ();

         table.setPreferredScrollableViewportSize(new Dimension(800, 100));
         table.setFillsViewportHeight(true);
         JScrollPane sp = new JScrollPane(table);
         model = new DefaultTableModel();
         Object[] column = {"Name", "Vehicle Number", "Email", "Charge", "Advance", "Date Issued"};
         final Object[] row = new Object[6];
         model.setColumnIdentifiers(column);
         table.setModel(model);
         table.getColumnModel().getColumn(0).setPreferredWidth(200);
         table.getColumnModel().getColumn(2).setPreferredWidth(200);
         table.getColumnModel().getColumn(5).setPreferredWidth(150);
         sp.setViewportView(table);
         
         JTable table2 = new JTable();
         table2.setPreferredScrollableViewportSize(new Dimension(800, 100));
         table2.setFillsViewportHeight(true);
         JScrollPane sp2 = new JScrollPane(table2);
         model2 = new DefaultTableModel();
         Object[] column2 = {"Vehicle Type", "Vehicle Number", "Vehicle Manufacturer", "Vehicle Model", "Vehicle Transmission", "Vehicle Color", "Vehicle Rate", "Vehicle Advance Pay"};
         final Object[] row2 = new Object[8];
         model2.setColumnIdentifiers(column2);
         table2.setModel(model2);
         table2.getColumnModel().getColumn(0).setPreferredWidth(200);
         table2.getColumnModel().getColumn(2).setPreferredWidth(200);
         table2.getColumnModel().getColumn(5).setPreferredWidth(150);
         sp2.setViewportView(table2);
         
         
         
         
         //1st Table
         Car1 carInfo1 = new Car1();

         row2[0] = carInfo1.getVehicleType();
         row2[1] = carInfo1.getVehicleNumber();
         row2[2] = carInfo1.getVehicleManufacturer();
         row2[3] = carInfo1.getVehicleModel();
         row2[4] = carInfo1.getVehicleTransmission();
         row2[5] = carInfo1.getVehicleColor();
         row2[6] = carInfo1.getVehicleRate();
         row2[7] = carInfo1.getVehicleAdvance();
         model2.addRow(row2);
         
         Car2 carInfo2 = new Car2();
         //2nd Table
         row2[0] = carInfo2.getVehicleType();
         row2[1] = carInfo2.getVehicleNumber();
         row2[2] = carInfo2.getVehicleManufacturer();
         row2[3] = carInfo2.getVehicleModel();
         row2[4] = carInfo2.getVehicleTransmission();
         row2[5] = carInfo2.getVehicleColor();
         row2[6] = carInfo2.getVehicleRate();
         row2[7] = carInfo2.getVehicleAdvance();
         model2.addRow(row2);
         
         Car3 carInfo3 = new Car3();
         //3rd Table
         row2[0] = carInfo3.getVehicleType();
         row2[1] = carInfo3.getVehicleNumber();
         row2[2] = carInfo3.getVehicleManufacturer();
         row2[3] = carInfo3.getVehicleModel();
         row2[4] = carInfo3.getVehicleTransmission();
         row2[5] = carInfo3.getVehicleColor();
         row2[6] = carInfo3.getVehicleRate();
         row2[7] = carInfo3.getVehicleAdvance();
         model2.addRow(row2);
         
         Car4 carInfo4 = new Car4();
         //4th Table
         row2[0] = carInfo4.getVehicleType();
         row2[1] = carInfo4.getVehicleNumber();
         row2[2] = carInfo4.getVehicleManufacturer();
         row2[3] = carInfo4.getVehicleModel();
         row2[4] = carInfo4.getVehicleTransmission();
         row2[5] = carInfo4.getVehicleColor();
         row2[6] = carInfo4.getVehicleRate();
         row2[7] = carInfo4.getVehicleAdvance();
         model2.addRow(row2);
         
         Car5 carInfo5 = new Car5();
         //5th Table
         row2[0] = carInfo5.getVehicleType();
         row2[1] = carInfo5.getVehicleNumber();
         row2[2] = carInfo5.getVehicleManufacturer();
         row2[3] = carInfo5.getVehicleModel();
         row2[4] = carInfo5.getVehicleTransmission();
         row2[5] = carInfo5.getVehicleColor();
         row2[6] = carInfo5.getVehicleRate();
         row2[7] = carInfo5.getVehicleAdvance();
         model2.addRow(row2);
         
         Car6 carInfo6 = new Car6();
         //6th Table
         row2[0] = carInfo6.getVehicleType();
         row2[1] = carInfo6.getVehicleNumber();
         row2[2] = carInfo6.getVehicleManufacturer();
         row2[3] = carInfo6.getVehicleModel();
         row2[4] = carInfo6.getVehicleTransmission();
         row2[5] = carInfo6.getVehicleColor();
         row2[6] = carInfo6.getVehicleRate();
         row2[7] = carInfo6.getVehicleAdvance();
         model2.addRow(row2);
         
         Car7 carInfo7 = new Car7();
         //7th Table
         row2[0] = carInfo7.getVehicleType();
         row2[1] = carInfo7.getVehicleNumber();
         row2[2] = carInfo7.getVehicleManufacturer();
         row2[3] = carInfo7.getVehicleModel();
         row2[4] = carInfo7.getVehicleTransmission();
         row2[5] = carInfo7.getVehicleColor();
         row2[6] = carInfo7.getVehicleRate();
         row2[7] = carInfo7.getVehicleAdvance();
         model2.addRow(row2);
         
        
         //2st Table
         row[0] = "Yap";
         row[1] = "ABC-1234";
         row[2] = "yelyap56@gmail.com";
         row[3] = "1000";
         row[4] = "3000";
         row[5] = "2022-11-12";

         model.addRow(row);

         //2nd Table
         row[0] = "Paolo";
         row[1] = "DEF-4567";
         row[2] = "baltazarpaolo0614@gmail.com";
         row[3] = "2000";
         row[4] = "6000";
         row[5] = "2022-11-13";

         model.addRow(row);


         //3rd Table
         row[0] = "Pauline";
         row[1] = "YAP-1227";
         row[2] = "psumang1@gmail.com";
         row[3] = "2500";
         row[4] = "7500";
         row[5] = "2022-11-13";

         model.addRow(row);


         //4th Table
         row[0] = "Sofia";
         row[1] = "PAO-0614";
         row[2] = "sdyunun1@gmail.com";
         row[3] = "2000";
         row[4] = "6000";
         row[5] = "2022-11-13";

         model.addRow(row);


         //5th Table
         row[0] = "Nico";
         row[1] = "PAU-0115";
         row[2] = "nsantos1@gmail.com";
         row[3] = "1000";
         row[4] = "3000";
         row[5] = "2022-11-14";

         model.addRow(row);



         //6th Table
         row[0] = "Patrick";
         row[1] = "XQC-1114";
         row[2] = "plgomez2@gmail.com";
         row[3] = "500";
         row[4] = "1500";
         row[5] = "2022-11-15";

         model.addRow(row);


         //7th Table
         row[0] = "Webster";
         row[1] = "GAB-2712";
         row[2] = "wwwpangan1@gmail.com";
         row[3] = "1500";
         row[4] = "4500";
         row[5] = "2022-11-15";

         model.addRow(row);
         
         
         addButton.addActionListener(new ActionListener(){
             public void actionPerformed(ActionEvent arg0){
                 JFrame f = new JFrame();
                 /*

                 String typeOfCar = text1.getText();
                 String vehicleNumber = text2.getText();
                 String manufacturerOfCar = text3.getText();
                 String modelOfCar = text4.getText();
                 String transmissionOfCar = text5.getText();
                 String colorOfCar = text6.getText();
                 JOptionPane.showMessageDialog(null,"Renting\n","Vehicle Type: "+typeOfCar+ "\nVehicle Number"+vehicleNumber+ "\nManufacturer: "+manufacturerOfCar+
                "\nModel"+modelOfCar+"\nTransmission: "+transmissionOfCar+ "\nColor: "+colorOfCar );
                 */
                
                
                
                String t1 = text1.getText();
                String t2 = text2.getText();
                String t3 = text3.getText();
                String t4 = text4.getText();
                String t5 = text5.getText();
                String t6 = text6.getText();
                
                int chargePerDay = Integer.parseInt(t4);
                int advancePay = Integer.parseInt(t5);
                //int balance = chargePerDay - advancePay;
                
                
                //Validates if textField is empty
                if (text1.getText().trim().length()==0){
                    JOptionPane.showMessageDialog(null, "You must complete all the information", "Invalid Input",
                    JOptionPane.ERROR_MESSAGE);
                }
                else if (text2.getText().trim().length()==0){
                    JOptionPane.showMessageDialog(null, "You must complete all the information", "Invalid Input",
                    JOptionPane.ERROR_MESSAGE);
                }
                else if (text3.getText().trim().length()==0){
                    JOptionPane.showMessageDialog(null, "You must complete all the information", "Invalid Input",
                    JOptionPane.ERROR_MESSAGE);
                }
                else if (text4.getText().trim().length()==0){
                    JOptionPane.showMessageDialog(null, "You must complete all the information", "Invalid Input",
                    JOptionPane.ERROR_MESSAGE);
                }
                else if (text5.getText().trim().length()==0){
                    JOptionPane.showMessageDialog(null, "You must complete all the information", "Invalid Input",
                    JOptionPane.ERROR_MESSAGE);
                }
                /*else if (text6.getText().trim().length()==0){
                    JOptionPane.showMessageDialog(null, "You must complete all the information", "Invalid Input",
                    JOptionPane.ERROR_MESSAGE);
                
                }
                */
                else{
                    
                    LocalDate currentDate = LocalDate.now(); // Create a date object
                    row[0] = text1.getText();
                    row[1] = text2.getText();
                    row[2] = text3.getText();
                    row[3] = text4.getText();
                    row[4] = text5.getText();
                    row[5] = currentDate;
                    model.addRow(row);
                    
                    JOptionPane.showMessageDialog(null,"Renting\n\nName: "+t1+ "\n\nNumber: "+t2+ "\n\nEmail: "+t3+ "\n\nCharge: " +t4+ "\n\nAdvance: "+t5+ "\n\nDate Issued: "+currentDate,"Receipt", 
                    JOptionPane.INFORMATION_MESSAGE );
                }
                
                
            } 
         });
         
         fillButton.addActionListener(new ActionListener(){
             public void actionPerformed(ActionEvent arg0){
                 //Car1
                 Car1 carInfo1 = new Car1();
                 String car1 = carInfo1.getVehicleNumber();
                 
                 //Car2
                 Car2 carInfo2 = new Car2();
                 String car2 = carInfo2.getVehicleNumber();
                 
                 //Car3
                 Car3 carInfo3 = new Car3();
                 String car3 = carInfo3.getVehicleNumber();
                 
                 //Car4
                 Car4 carInfo4 = new Car4();
                 String car4 = carInfo4.getVehicleNumber();
                 
                 //Car5
                 Car5 carInfo5 = new Car5();
                 String car5 = carInfo5.getVehicleNumber();
                 
                 //Car6
                 Car6 carInfo6 = new Car6();
                 String car6 = carInfo6.getVehicleNumber();
                 
                 //Car7
                 Car7 carInfo7 = new Car7();
                 String car7 = carInfo7.getVehicleNumber();
                 
                 
                 LocalDate currentDate = LocalDate.now();
                 
                 
                 if(text2.getText().equals(car1)){
                     
                     String rateCar1 = carInfo1.getVehicleRate();
                     String advanceCar1 = carInfo1.getVehicleAdvance();
                     text4.setText(rateCar1);
                     text5.setText(advanceCar1);
                     text6.setText(" "+currentDate);
                     
                     
                 }
                 
                 else if(text2.getText().equals(car2)){
                     String rateCar2 = carInfo2.getVehicleRate();
                     String advanceCar2 = carInfo2.getVehicleAdvance();
                     text4.setText(rateCar2);
                     text5.setText(advanceCar2);
                     text6.setText(" "+currentDate);
                 }
                 
                 else if(text2.getText().equals(car3)){
                     String rateCar3 = carInfo3.getVehicleRate();
                     String advanceCar3 = carInfo3.getVehicleAdvance();
                     text4.setText(rateCar3);
                     text5.setText(advanceCar3);
                     text6.setText(" "+currentDate);

                 }
                 else if(text2.getText().equals(car4)){
                     String rateCar4 = carInfo4.getVehicleRate();
                     String advanceCar4 = carInfo4.getVehicleAdvance();
                     text4.setText(rateCar4);
                     text5.setText(advanceCar4);
                     text6.setText(" "+currentDate);
                     
                 }
                 else if(text2.getText().equals(car5)){
                     String rateCar5 = carInfo5.getVehicleRate();
                     String advanceCar5 = carInfo5.getVehicleAdvance();
                     text4.setText(rateCar5);
                     text5.setText(advanceCar5);
                     text6.setText(" "+currentDate);
                 }
                 else if(text2.getText().equals(car6)){
                     String rateCar6 = carInfo6.getVehicleRate();
                     String advanceCar6 = carInfo6.getVehicleAdvance();
                     text4.setText(rateCar6);
                     text5.setText(advanceCar6);
                     text6.setText(" "+currentDate);
                 }
                 else if(text2.getText().equals(car7)){
                     String rateCar7 = carInfo7.getVehicleRate();
                     String advanceCar7 = carInfo7.getVehicleAdvance();
                     text4.setText(rateCar7);
                     text5.setText(advanceCar7);
                     text6.setText(" "+currentDate);
                 }
                 
             }
         });

         clearButton.addActionListener(new ActionListener(){
             public void actionPerformed(ActionEvent arg0){
                text1.setText(null);
                text2.setText(null);
                text3.setText(null);
                text4.setText(null);
                text5.setText(null);
                text6.setText(null);

             }
         });
         
         exitButton.addActionListener(new ActionListener(){
             public void actionPerformed(ActionEvent arg0){
                 f.dispose();
            }    
         });
         
         
         


         gridConstraints.gridx = 3;
         gridConstraints.gridy = 6;
         gridConstraints.gridheight = 8;
         gridConstraints.insets = new Insets(0,20,0,0);
         f.getContentPane().add(sp, gridConstraints);
         
         gridConstraints.gridx = 3;
         gridConstraints.gridy = 0;
         gridConstraints.gridheight = 8;
         gridConstraints.insets = new Insets(0,20,0,0);
         f.getContentPane().add(sp2, gridConstraints);
         
        

         f.pack();


     }
}
