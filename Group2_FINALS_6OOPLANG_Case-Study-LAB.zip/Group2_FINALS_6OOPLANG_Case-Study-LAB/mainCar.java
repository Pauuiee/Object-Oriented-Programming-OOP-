
public class mainCar
{
    String vehicleType;
    String vehicleNumber;
    String vehicleManufacturer;
    String vehicleModel;
    String vehicleTransmission;
    String vehicleColor;
    String vehicleRate;
    String vehicleAdvance;
    
    public mainCar(){
        
    }
}
