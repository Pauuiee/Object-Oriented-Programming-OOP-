import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class addClientt {



     public static void main(String[] args){
         frame();
     }

     public static void frame(){
        DefaultTableModel model;

        JFrame f = new JFrame();

        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.setLocationRelativeTo(null);

         f.getContentPane().setLayout(new GridBagLayout());
         GridBagConstraints gridConstraints = new GridBagConstraints();

         //Title
         JLabel title = new JLabel("Add a Client");
         title.setFont(new Font("Arial", Font.PLAIN, 25));
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 0;
         gridConstraints.insets = new Insets(10,0,30,0);
         f.getContentPane().add(title, gridConstraints);

         //Labels
         JLabel nameLabel = new JLabel("Name");
         nameLabel.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 1;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(nameLabel, gridConstraints);

         JLabel addressLabel = new JLabel("Address");
         addressLabel.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 2;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(addressLabel, gridConstraints);

         JLabel emailLabel = new JLabel("Email");
         emailLabel.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 3;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(emailLabel, gridConstraints);

         JLabel phoneLabel = new JLabel("Phone Number");
         phoneLabel.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 4;
         gridConstraints.insets = new Insets(10,0,0,0);
         f.getContentPane().add(phoneLabel, gridConstraints);


         //TextField
         JTextField text1 = new JTextField();
         text1.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 1;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text1, gridConstraints);

         JTextField text2 = new JTextField();
         text2.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 2;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text2, gridConstraints);

         JTextField text3 = new JTextField();
         text3.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 3;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text3, gridConstraints);

         JTextField text4 = new JTextField();
         text4.setColumns(20);
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 4;
         gridConstraints.insets = new Insets(10,10,0,0);
         f.getContentPane().add(text4, gridConstraints);

         //Buttons
         JButton addButton = new JButton("Add");
         addButton.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 0;
         gridConstraints.gridy = 15;
         gridConstraints.gridwidth = 1;
         gridConstraints.insets = new Insets(40,0,0,0);
         f.getContentPane().add(addButton, gridConstraints);

         JButton clearButton = new JButton("Clear");
         clearButton.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 1;
         gridConstraints.gridy = 15;
         gridConstraints.insets = new Insets(40,10,0,0);
         f.getContentPane().add(clearButton, gridConstraints);
         
         JButton exitButton = new JButton("Exit");
         exitButton.setFont(new Font("Arial", Font.PLAIN, 15));
         gridConstraints.gridx = 2;
         gridConstraints.gridy = 15;
         gridConstraints.gridwidth = 2;
         gridConstraints.insets = new Insets(40,0,0,0);
         f.getContentPane().add(exitButton, gridConstraints);




         f.setVisible(true);


         JTable table = new JTable ();

         table.setPreferredScrollableViewportSize(new Dimension(500, 200));
         table.setFillsViewportHeight(true);
         JScrollPane sp = new JScrollPane(table);
         model = new DefaultTableModel();
         Object[] column = {"Name", "Address", "Email", "Phone Number"};
         final Object[] row = new Object[6];
         model.setColumnIdentifiers(column);
         table.setModel(model);
         sp.setViewportView(table);
         gridConstraints.gridx = 3;
         gridConstraints.gridy = 1;
         gridConstraints.gridheight = 8;
         gridConstraints.insets = new Insets(0,20,0,0);
         f.getContentPane().add(sp, gridConstraints);
         
         
         
         //Special Client
         row[0] = "Joji";
         row[1] = "Zone 5 San Matias, Sta Rita, Pampanga";
         row[2] = "joji@gmail.com";
         row[3] = "09926077121";

         model.addRow(row);
         
         //1st Client
         row[0] = "Jonathan";
         row[1] = "Zone 5 San Matias, Sta Rita, Pampanga";
         row[2] = "theoriginaljoestar1@gmail.com";
         row[3] = "09926077121";

         model.addRow(row);
         
         //2nd Client
         row[0] = "Joseph";
         row[1] = "Zone 5 San Matias, Sta Rita, Pampanga";
         row[2] = "thebestjoestar123@gmail.com";
         row[3] = "09926077121";

         model.addRow(row);
         
         //3rd Client
         row[0] = "Jotaro";
         row[1] = "Zone 5 San Matias, Sta Rita, Pampanga";
         row[2] = "kujotaro@gmail.com";
         row[3] = "09926077121";

         model.addRow(row);
         
         
         //4th Client
         row[0] = "Josuke";
         row[1] = "Zone 5 San Matias, Sta Rita, Pampanga";
         row[2] = "diamondhands5@gmail.com";
         row[3] = "09926077121";

         model.addRow(row);
         
         //5th Client
         row[0] = "Giorno";
         row[1] = "Zone 5 San Matias, Sta Rita, Pampanga";
         row[2] = "sonofgod5@gmail.com";
         row[3] = "09926077121";

         model.addRow(row);
         
         //6th Client
         row[0] = "Jolyne";
         row[1] = "Zone 5 San Matias, Sta Rita, Pampanga";
         row[2] = "freestoner66@gmail.com";
         row[3] = "09926077121";

         model.addRow(row);

         addButton.addActionListener(new ActionListener() {
             @Override
             public void actionPerformed(ActionEvent arg0) {
                 
                 if (text1.getText().trim().length()==0){
                     JOptionPane.showMessageDialog(null, "You must complete all the information", "Invalid Input",
                     JOptionPane.ERROR_MESSAGE);
                 }
                 else if (text2.getText().trim().length()==0){
                     JOptionPane.showMessageDialog(null, "You must complete all the information", "Invalid Input",
                     JOptionPane.ERROR_MESSAGE);
                 }
                 else if (text3.getText().trim().length()==0){
                     JOptionPane.showMessageDialog(null, "You must complete all the information", "Invalid Input",
                     JOptionPane.ERROR_MESSAGE);
                 }
                 else if (text4.getText().trim().length()==0){
                     JOptionPane.showMessageDialog(null, "You must complete all the information", "Invalid Input",
                     JOptionPane.ERROR_MESSAGE);
                 }
                 else{
                    row[0] = text1.getText();
                    row[1] = text2.getText();
                    row[2] = text3.getText();
                    row[3] = text4.getText();
                    model.addRow(row);
                 }
             }
         });
         
         clearButton.addActionListener(new ActionListener(){
             public void actionPerformed(ActionEvent arg0){
                text1.setText(null);
                text2.setText(null);
                text3.setText(null);
                text4.setText(null);

             }
         });
         
         exitButton.addActionListener(new ActionListener(){
             public void actionPerformed(ActionEvent arg0){
                 f.dispose();
            }    
         });
         


         

         f.pack();


     }
    
}
