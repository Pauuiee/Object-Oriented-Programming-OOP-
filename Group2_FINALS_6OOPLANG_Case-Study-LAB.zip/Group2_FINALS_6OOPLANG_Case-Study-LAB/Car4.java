
public class Car4 extends mainCar
{
    public Car4(){
        this.vehicleType = "SUV";
        this.vehicleNumber = "ALK-4332";
        this.vehicleManufacturer = "Ford";
        this.vehicleModel = "Everest(2017)";
        this.vehicleTransmission = "Automatic"; 
        this.vehicleColor = "Black"; 
        this.vehicleRate = "3000";
        this.vehicleAdvance = "9000";
    }
    
    public String getVehicleType(){
        return vehicleType;
    }
    
    public String getVehicleNumber(){
        return vehicleNumber;
    }
    
    public String getVehicleManufacturer(){
        return vehicleManufacturer;
    }
    
    public String getVehicleModel(){
        return vehicleModel;
    }
    
    public String getVehicleTransmission(){
        return vehicleTransmission;
    }
    
    public String getVehicleColor(){
        return vehicleColor;
    }
    
    public String getVehicleRate(){
        return vehicleRate;
    }
    
    public String getVehicleAdvance(){
        return vehicleAdvance;
    }
    
}
