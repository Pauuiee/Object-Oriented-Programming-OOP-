package Inheritance;

public class Dog extends Animal
{
    public String DoggyName;
    
    public void getDogName(){
        setDogName(DoggyName);
    }
    
    public void setDogName(String DoggyName){
        System.out.println(DoggyName);
    }
    
    public Dog(String color, String LegsNum){
        super(color, LegsNum);
        this.DoggyName = "Moshi";
        
        System.out.println("My dog's name is "+DoggyName+". His skin color is "+color+" and he has "+LegsNum+" legs.");
    }

}
