package Inheritance;

public class Animal
{
    String color;
    String LegsNum;
    
    public Animal(){
        
    }
    
    public Animal(String color, String LegsNum){
        showInfo(color, LegsNum);
    }
    
    /**public String setColor(){
        return color;
    }
    
    public void Color(String color){
        this.color = color;
    }
    
    public String setLegsNum(){
        return LegsNum;
    }
    
    public void getLegsNum(String LegsNum){
        this.LegsNum = LegsNum;
    }**/
    
    public void showInfo(String color, String LegsNum){
        System.out.println(color);
        System.out.println(LegsNum);
    }
}