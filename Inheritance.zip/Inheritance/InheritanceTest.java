package Inheritance;

public class InheritanceTest
{
    public static void main(String[] args){
        Dog dog1 = new Dog("Brown", "3");
    }
}