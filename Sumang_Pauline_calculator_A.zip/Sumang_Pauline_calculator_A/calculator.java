import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class calculator extends JFrame
{
    JButton calc = new JButton();
    JButton exit = new JButton();
    
    JTextField Oper1 = new JTextField();
    JTextField Operator = new JTextField();
    JTextField Oper2 = new JTextField();
    JTextField Result = new JTextField();
    
    JLabel Oone = new JLabel();
    JLabel Ope = new JLabel();
    JLabel Otwo = new JLabel();
    JLabel Res = new JLabel();
    
    public calculator(){
    JFrame window = new JFrame();
    window.setTitle("Simple Calculator");
    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    getContentPane().setLayout(new GridBagLayout());
    GridBagConstraints gridBag = new GridBagConstraints ();
    
    //TEXTFIELDS
    Oper1.setText("");
    Oper1.setColumns(15);
    gridBag.gridx = 1;
    gridBag.gridy = 0;
    getContentPane().add(Oper1, gridBag);

    Operator.setText("");
    Operator.setColumns(15);
    gridBag.gridx = 1;
    gridBag.gridy = 1;
    getContentPane().add(Operator, gridBag);
    
    Oper2.setText("");
    Oper2.setColumns(15);
    gridBag.gridx = 1;
    gridBag.gridy = 2;
    getContentPane().add(Oper2, gridBag);
    
    Result.setText("");
    Result.setColumns(15);
    gridBag.gridx = 1;
    gridBag.gridy = 3;
    getContentPane().add(Result, gridBag);
    
    
    //LABELS
    Oone.setText("Operand 1: ");
    gridBag.gridx = 0;
    gridBag.gridy = 0;
    getContentPane().add(Oone, gridBag);
    
    Ope.setText("Operator: ");
    gridBag.gridx = 0;
    gridBag.gridy = 1;
    getContentPane().add(Ope, gridBag);

    Otwo.setText("Operand 2: ");
    gridBag.gridx = 0;
    gridBag.gridy = 2;
    getContentPane().add(Otwo, gridBag);
    
    Res.setText("Result: ");
    gridBag.gridx = 0;
    gridBag.gridy = 3;
    getContentPane().add(Res, gridBag);

    //BUTTONS
    calc.setText("Calculate");
    gridBag.gridx = 0;
    gridBag.gridy = 4;
    getContentPane().add(calc, gridBag);
    
    exit.setText("Exit");
    gridBag.gridx = 1;
    gridBag.gridy = 4;
    getContentPane().add(exit, gridBag);
    
    calc.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            calculationButtonActionPerformed(e);    
        }
    });
    
    exit.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
            ExitButtonActionPerformed(e);    
        }
    });
    
    pack();
    } 
    
    public void calculationButtonActionPerformed(ActionEvent e){
        if (Operator.getText().equals("+")){
            double val1 = Double.parseDouble(Oper1.getText());
            double val2 = Double.parseDouble(Oper2.getText());
            double ans = val1 + val2;
            
            Result.setText(""+ans);
        }
        
        else if (Operator.getText().equals("-")){
            double val1 = Double.parseDouble(Oper1.getText());
            double val2 = Double.parseDouble(Oper2.getText());
            double ans = val1 - val2;
            Result.setText(""+ans);   
            
        }
        
        else if (Operator.getText().equals("*")){
            double val1 = Double.parseDouble(Oper1.getText());
            double val2 = Double.parseDouble(Oper2.getText());
            double ans = val1 * val2;
            Result.setText(""+ans);   
            
        }
        else if (Operator.getText().equals("/")){
            double val1 = Double.parseDouble(Oper1.getText());
            double val2 = Double.parseDouble(Oper2.getText());
            double ans = val1 / val2;
            Result.setText(""+ans);   
            
        }
    }
    
    public void ExitButtonActionPerformed(ActionEvent e){
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f,"Exiting Simple Calculator");
        System.exit(0);
    }

        public static void main(String []args){
        new calculator().show();
    }
}
